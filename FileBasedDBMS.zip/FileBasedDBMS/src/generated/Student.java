public class Student {

    public int id;
    public String name;
    public double cgpa;

    public Student() {}

}
